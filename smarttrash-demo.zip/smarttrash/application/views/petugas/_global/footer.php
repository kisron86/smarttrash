<!-- Footer -->
            <footer id="page-footer" class="opacity-0">
                <div class="content py-20 font-size-xs clearfix">
                    <div class="float-left">
                        <a class="font-w600" href="#" target="_blank">PENS</a> &copy; <span class="js-year-copy">2019</span>
                    </div>
                </div>
            </footer>
            <!-- END Footer -->
        </div>
        <!-- END Page Container -->

        <!-- Codebase Core JS -->
        <script src="<?=base_url();?>assets/js/core/bootstrap.bundle.min.js"></script>
        <script src="<?=base_url();?>assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="<?=base_url();?>assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="<?=base_url();?>assets/js/core/jquery.appear.min.js"></script>
        <script src="<?=base_url();?>assets/js/core/jquery.countTo.min.js"></script>
        <script src="<?=base_url();?>assets/js/core/js.cookie.min.js"></script>
        <script src="<?=base_url();?>assets/js/codebase.js"></script>

        <script src="<?=base_url();?>assets/toastr/js/toastr.min.js"></script>

		<!-- Page JS Plugins -->
        <script src="<?=base_url();?>assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?=base_url();?>assets/js/plugins/datatables/dataTables.bootstrap4.min.js"></script>

        <!-- Page JS Code -->
        <script src="<?=base_url();?>assets/js/pages/be_tables_datatables.js"></script>

    </body>
</html>
